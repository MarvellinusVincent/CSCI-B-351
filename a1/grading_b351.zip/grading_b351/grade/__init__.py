#!/usr/bin/python3

from .generate_html import safeGrade, batchGrade, defaultGrade, defaultCompilationTest
