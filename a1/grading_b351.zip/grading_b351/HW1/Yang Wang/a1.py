#!/usr/bin/python3
# B351/Q351 SP 2023
# Do not share these assignments or their solutions outside of this class.

#################################
#                               #
# Assignment 1: Python Methods  #
#                               #
#################################


